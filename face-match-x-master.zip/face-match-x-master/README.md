# face-match-x
Face matching system using Tensorflow/Keras deployed and as a Python (Flask) web App
> Note: You need Python3 to run this
<br><br>
### How to run?
```sh
$ cd face-match-x
$ pip install -r requirements.txt
$ python app.py
```
### Screenshot
<img src = "face-match-x-screenshot.png">  
